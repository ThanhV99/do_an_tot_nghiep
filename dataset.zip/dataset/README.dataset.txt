# datn > 2022-08-07 2:34pm
https://universe.roboflow.com/object-detection/datn-5r3a7

Provided by Roboflow
License: CC BY 4.0

